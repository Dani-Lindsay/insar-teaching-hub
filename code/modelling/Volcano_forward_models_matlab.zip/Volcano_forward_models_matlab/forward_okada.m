function [model,rms,disp] = forward_okada(gps,source,source_flg,runs,h_flg,ins_flg,lambda,mu,locs,locs_ins)


%% set up arrays
 str = zeros(runs,1);
 dip = zeros(runs,1);
 rake = zeros(runs,1);
 len = zeros(runs,1);
 slip = zeros(runs,1);
 rake = zeros(runs,1);
 bot = zeros(runs,1);
 top = zeros(runs,1);
 x_surf = zeros(runs,1);
 y_surf = zeros(runs,1);
 pos = zeros(runs,2);
 model = zeros(runs,10);
  
if h_flg == 1
    obs = [gps(:,3); gps(:,5)];
    errs = [gps(:,4); gps(:,6)];
    err_vcm = diag(errs);
else
    obs = [gps(:,3); gps(:,5); gps(:,7)];
    errs = [gps(:,4); gps(:,6); gps(:,8);];
    err_vcm = diag(errs);
end

disp = zeros(size(gps,1),3,runs);
los = zeros(3*size(gps,1),runs);
los_best_a = zeros(3*size(gps,1),runs);


%%

if source_flg == 'M'

    z = zeros(runs,1);
    pos = zeros(runs,2);
    model = zeros(runs,4);
    vol = zeros(runs,1);
    for j = 1:runs
        pos(j,:) = [randi([-source.max_x source.max_x]) randi([-source.max_y source.max_y])];
        vol(j,1) = 1;
        z(j,1) = randi([source.mind source.maxd-1])+rand(1);
        model(j,:) = [pos(j,1) pos(j,2) 1 z(j)/1000];
        
        [ux,uy,uz] = rngchn_mogi(model(j,2)/1000,model(j,1)/1000,model(j,4),1,locs(:,2)/1000,locs(:,1)/1000,ones(size(locs,1),3));
       
        if h_flg == 1
            A = [ux; uy];  
        else 
            A = [ux; uy;uz];
        end

        XtX = A'*inv(err_vcm)*A;
        Xty = A'*inv(err_vcm)*obs;
        vol(j,1) = inv(XtX)*Xty;
       
        model(j,3) = vol(j);
        
        U = A*vol(j);
         if h_flg == 1
            disp(:,:,j) = reshape(U,[],2);
         else
            disp(:,:,j) = reshape(U,[],3);
         end
        
        
        [L1, L2, rms(j,1), normalised]=calc_misfit(obs', U);
    
    if j == 1
        U_best = U;
        model_best = model(j,:);
        idx = j;
        rms_best = rms(j,1)
    
    elseif rms(j,1)<rms_best
                U_best = U;
                model_best = model(j,:);
                idx = j;
                rms_best = rms(j,1);
          
    end

end

elseif source_flg == 'D'
locs = locs';
for j = 1:runs
    %tic
    if j == 1
    str(j,1) = 178;
    dip(j,1) = 69;
    top(j,1) = 648;
    len(j,1) = 545;
    op(j,1) = 0.457;
    bot(j,1) = 1591.5;   
    x_surf(j,1) = 936.4;
    y_surf(j,1) = 102.1;
     
    else

   
    str(j,1) = randi([source.min_str source.max_str]);
    
    dip(j,1) = randi([source.dip_l source.dip_u]);
    top(j,1) = randi([source.min_top source.max_top]);
    len(j,1) = randi([source.min_length source.max_length]);
    if source.max_op < 1
        op(j,1) = rand(1);
    else
        op(j,1) = randi([floor(source.min_op) source.max_op-1]) + rand(1);
    end

    bot(j,1) = top(j)+(0.5 - (0.5-2).*rand(1))*len(j);   
    pos(j,:) = [randi([-source.max_x source.max_x]) randi([-source.max_y source.max_y])];
    proj_len = top(j)/tand(dip(j));
    x_surf(j,1) = pos(j,1)+(sind(dip(j)*str(j))*proj_len);
    y_surf(j,1) = pos(j,2)-(cosd(dip(j)*str(j))*proj_len);

    end

           
    model(j,:) = [x_surf(j,1) y_surf(j,1) str(j) dip(j) -90 op(j) len(j) top(j) bot(j) 2]';    
    vol(j,1) = op(j,1)*((len(j,1)*(bot(j,1)-top(j,1))));
    
[woo,m]=size(model);
[woo,n]=size(locs) ;

% Then set up a loop to call Okada for each fault segment

%for i=1:1 ; % debug line
clear u ux uy uz
 %for i=1:1 ;
    
% Call the Okada function
    
    [u, flag]=disloc3d3(model(j,:)', locs,lambda,mu) ;
    
    ux = u(1,:);
    uy = u(2,:);
    uz = u(3,:);
    
% Calculate the LOS component of displacement at each location
    
   % a=dot(u, los) ; %octave won't do dot products on multiple vectors
    
%    clear u flag, a ;
    
 
out = [sum(ux,3)' sum(uy,3)' sum(uz,3)'];

%dlmwrite('dyke.xyz',out,'delimiter','\t','precision','%10.4f')

ux = out(:,1);
uy = out(:,2);
uz = out(:,3);

    U(:,j) = [ux;uy;uz]*1000;
    disp(:,:,j) = [ux uy uz]*1000;
    tmp_obs = obs;%cat(1,obs,obs2(:,3));
    tmp_los = U(:,j);%cat(1,los,los_d);
    [L1, L2, rms(j,1), normalised]=calc_misfit(tmp_obs,tmp_los);
    
    
    if j == 1
        U_best_a = tmp_los;
        model_best = model(j,:);
        idx = j;
        rms_best = rms(j,1)
    
    elseif rms(j,1)<rms_best
                U_best_a = tmp_los;
                
                model_best = model(j,:);
                idx = j;
                rms_best = rms(j,1);
          
    end

end

  elseif source_flg == 'P'
    locs = locs';
    P_G = zeros(runs,1);
    z = zeros(runs,1);
    a = zeros(runs,1);
    pos = zeros(runs,2);
    model = zeros(runs,5);

    for j = 1:runs
        pos(j,:) = [randi([-source.max_x source.max_x]) randi([-source.max_y source.max_y])];
        z(j,1) = randi([source.mind source.maxd-1])+rand(1);
        a(j) = randi([source.min_a source.max_a-1000])+(rand(1)*1000);
        model(j,:) = [pos(j,1) pos(j,2) z(j) a(j) 1];

        [U,dV(j,1)] = pennySource(model(j,:),locs,0.25);
        ux = U(1,:)';  uy = U(2,:)';  uz = U(3,:)';
        disp(:,:,j) = [ux uy uz];
        if h_flg == 1
            A = [ux;uy]*1000;
        else
            A = [ux;uy;uz]*1000;
        end

        XtX = A'*inv(err_vcm)*A;
        Xty = A'*inv(err_vcm)*obs;
        P_G(j,1) = inv(XtX)*Xty;
        dV(j,1) =dV(j,1)/(1/P_G(j,1));
        U = A*P_G(j,1);
        model(j,5) = dV(j,1);
        [L1, L2, rms(j,1), normalised]=calc_misfit(obs', U);
    
        if j == 1
            U_best = U;
            model_best = model(j,:);
            idx = j;
            rms_best = rms(j,1)
    
        elseif rms(j,1)<rms_best
                U_best = U;
                model_best = model(j,:);
                idx = j;
                rms_best = rms(j,1);
          
        end

    end

    elseif source_flg == 'S'
    locs = locs';    
    model = zeros(runs,10);
    for j = 1:runs
        pos(j,:) = [randi([-source.max_x source.max_x]) randi([-source.max_y source.max_y])];
        if source.max_op < 1
            op(j,1) = rand(1);
            else
            op(j,1) = randi([floor(source.min_op) source.max_op-1]) + rand(1);
        end
        len(j,1) = randi([source.min_length source.max_length]);
        width(j,1) = len(j)+(0.5 - (0.5-2).*rand(1))*len(j);   
        z(j,1) = randi([source.min_d source.max_d])+(1000*rand(1));
        str(j,1) = randi([source.min_str source.max_str]);
        model(j,:) = [len(j,1) width(j,1) z(j,1) 0 str(j,1) pos(j,:) 0 0 op(j,1)];
    
   
        [U] = disloc(model(j,:)',locs(1:2,:),0.25);
        ux = U(1,:)';  uy = U(2,:)';  uz = U(3,:)';
        disp(:,:,j) = [ux uy uz];
        if h_flg == 1
            U = [ux;uy]*1000;
        else
            U = [ux;uy;uz]*1000;
        end

        [L1, L2, rms(j,1), normalised]=calc_misfit(obs', U);
    
        if j == 1
            U_best = U;
            model_best = model(j,:);
            idx = j;
            rms_best = rms(j,1)
    
        elseif rms(j,1)<rms_best
                U_best = U;
                model_best = model(j,:);
                idx = j;
                rms_best = rms(j,1);
          
        end

    end

elseif source_flg == 'Y'
    locs = locs';
    P_G = zeros(runs,1);
    z = zeros(runs,1);
    a = zeros(runs,1);
    pos = zeros(runs,2);
    model = zeros(runs,8);

    for j = 1:runs
        pos(j,:) = [randi([-source.max_x source.max_x]) randi([-source.max_y source.max_y])];
        z(j,1) = randi([source.min_d source.max_d-1])+rand(1);
        len(j) = randi([floor(source.min_length) source.max_length-1000])+(rand(1)*1000);
        a(j) = rand(1);
        dip(j,1) = randi([source.dip_l source.dip_u]);
        str(j,1) = randi([source.min_str source.max_str]);
        
        model(j,:) = [pos(j,1) pos(j,2) z(j) len(j) a(j) str(j) dip(j) 1];

        [U] = yangSource(model(j,:),locs,0.25);
        ux = U(1,:)';  uy = U(2,:)';  uz = U(3,:)';
        disp(:,:,j) = [ux uy uz];
        if h_flg == 1
            A = [ux;uy]*1000;
        else
            A = [ux;uy;uz]*1000;
        end

        XtX = A'*inv(err_vcm)*A;
        Xty = A'*inv(err_vcm)*obs;
        P_G(j,1) = inv(XtX)*Xty;
        model(j,8) = P_G(j,1);
        U = A*P_G(j,1);
        [L1, L2, rms(j,1), normalised]=calc_misfit(obs', U);
    
        if j == 1
            U_best = U;
            model_best = model(j,:);
            idx = j;
            rms_best = rms(j,1)
    
        elseif rms(j,1)<rms_best
                U_best = U;
                model_best = model(j,:);
                idx = j;
                rms_best = rms(j,1);
          
        end
    end
    
end
return

