
clear all
addpath(genpath('DeformationSources'))

source_flg = 'D'; % Source type: M = Mogi, D = dyke, S = Sill, P = pennyshaped crack
gps = load('gps.txt'); % Data file lon, lat,east,east_err,north,north_err,up,up_err
h_flg = 0; % horizontal flag. If only horizonal compoenents of GNSS being used
ins_flg = 1; %InSAR flag. If 1, predict InSAR displacement on specified grid
runs = 100000; % Number of forward simulations to run
lambda = 2.5e10; % elastic moduli
mu = 2.5e10;

xc = -62.2; yc = 16.75; % Origin point
rms_per = 0.05; % For plotting, find all solutions within 5% of minimum misfit

%% Bounding area and grid if predicted InSAR displacements are wanted 
if ins_flg == 1
ifghdr.xfirst = -62.4;
ifghdr.yfirst = 16.9;
ifghdr.xend = -62.0;
ifghdr.yend = 16.5;
ifghdr.xstep = 0.001;
ifghdr.ystep = -0.001;
x = ifghdr.xfirst:ifghdr.xstep:ifghdr.xend;
y = ifghdr.yfirst:ifghdr.ystep:ifghdr.yend;

[xx,yy]=meshgrid(x,y);
x_ins = reshape(xx,[],1);
y_ins = reshape(yy,[],1);
xy_ins = llh2local([x_ins(:,1) y_ins(:,1)]',[xc yc])'*1000; % convert from geodetic to metres.
locs_ins = [xy_ins(:,1) xy_ins(:,2) zeros(size(xy_ins,1),1)];
end
% Conver GNSS locations to m

xy = llh2local([gps(:,1) gps(:,2)]',[xc yc])'*1000; % convert from geodetic to metres.
locs = [xy(:,1) xy(:,2) zeros(size(xy,1),1)];

%%

if source_flg == 'M'
%Parameters for Mogi
source.max_x = 10000; % min/max x distance from origin
source.max_y = 10000; % min/max y distance from origin
source.mind = 2000;
source.maxd = 10000;

elseif source_flg == 'D'
%Parameters for Dyke
source.max_x = 10000; % min/max x distance from origin in metres
source.max_y = 10000; % min/max y distance from origin in metres
source.dip_l = 50; % Minimum dip
source.dip_u = 90; % Maximum dip
source.min_str = 30; % Min strike N.B right hand rule applies with dip direction being 90 degrees clockwise of stirke i.e strike of 0 will have dip to East.
source.max_str = 180;
source.min_op = 0.1; %min opening in metres
source.max_op = 3; % max opening in metres
source.min_length = 500; %min length in metres
source.max_length = 5000; %max length in metres
source.min_top = 5; % Min top depth in metres N.B Bottom is set as 0.5 - 2 times the length
source.max_top = 3000; %Max top depth

elseif source_flg == 'P'
%Parameters for Penny shaped crack
source.max_x = 10000; % min/max x distance from origin
source.max_y = 10000; % min/max y distance from origin
source.mind = 2000;
source.maxd = 10000;
source.min_a = 500; %Minimum radius in metres
source.max_a = 5000; % Maximum radius

elseif source_flg == 'S'
%Parameters for Sill
source.max_x = 10000; % min/max x distance from origin in metres
source.max_y = 10000; % min/max y distance from origin in metres
source.min_str = 30; % Min strike N.B right hand rule applies with dip direction being 90 degrees clockwise of stirke i.e strike of 0 will have dip to East.
source.max_str = 180;
source.min_op = 0.1; %min opening in metres
source.max_op = 3; % max opening in metres
source.min_length = 500; %min length in metres
source.max_length = 5000; %max length in metres
source.min_d = 5; % Min top depth in metres N.B Bottom is set as 0.5 - 2 times the length
source.max_d = 3000; %Max top depth

elseif source_flg == 'Y'
%Parameters for Prolate spheroid
source.max_x = 10000; % min/max x distance from origin in metres
source.max_y = 10000; % min/max y distance from origin in metres
source.min_str = 30; % Min strike N.B right hand rule applies with dip direction being 90 degrees clockwise of stirke i.e strike of 0 will have dip to East.
source.max_str = 180;
source.min_length = 500; %min length in metres
source.max_length = 5000; %max length in metres
source.min_d = 5; % Min top depth in metres N.B Bottom is set as 0.5 - 2 times the length
source.max_d = 3000; %Max top depth
source.dip_l = 50; % Minimum dip
source.dip_u = 90; % Maximum dip

end


    [model, rms, disp] = forward_okada(gps,source,source_flg,runs,h_flg,ins_flg,lambda,mu,locs);
plot_output

if ins_flg == 1

    best = find(rms==min(rms));
    %Assuming positive range change is towards sensor
        losa = repmat([-0.5469 -0.1537 0.8223],size(locs_ins,1),1); %Approx LOS vector for ascending sentinel
        losd = repmat([0.5469 -0.1537 0.8223],size(locs_ins,1),1); %Approx LOS vector for descending sentinel

    if source_flg == 'M'

        [ux,uy,uz] = rngchn_mogi(model(best,2)/1000,model(best,1)/1000,model(best,4),model(best,3),locs_ins(:,2)/1000,locs_ins(:,1)/1000,ones(size(locs_ins,1),3));
       
        U_losa = ux.*losa(:,1) + uy.*losa(:,2) + uz.*losa(:,3); 
        U_losd = ux.*losd(:,1) + uy.*losd(:,2) + uz.*losd(:,3);
        figure
        subplot(1,2,1)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losa,'filled')
        title('Simulated Ascending in mm')
        subplot(1,2,2)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losd,'filled')
        title('Simulated Descending in mm')

    

elseif source_flg == 'D'

         [u, flag]=disloc3d3(model(best,:)', locs_ins',lambda,mu) ;
    
    ux = u(1,:);
    uy = u(2,:);
    uz = u(3,:);
 
    out = [sum(ux,3)' sum(uy,3)' sum(uz,3)'];
    ux = out(:,1)*1000;
    uy = out(:,2)*1000;
    uz = out(:,3)*1000;
       
        U_losa = ux.*losa(:,1) + uy.*losa(:,2) + uz.*losa(:,3); 
        U_losd = ux.*losd(:,1) + uy.*losd(:,2) + uz.*losd(:,3);
        figure
        subplot(1,2,1)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losa,'filled')
        title('Simulated Ascending in mm')
        subplot(1,2,2)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losd,'filled')
        title('Simulated Descending in mm')

elseif source_flg == 'S'
    locs_ins = locs_ins';
    [U] = disloc(model(best,:)',locs_ins(1:2,:),0.25);
        ux = U(1,:)';  uy = U(2,:)';  uz = U(3,:)';
             
        U_losa = ux.*losa(:,1) + uy.*losa(:,2) + uz.*losa(:,3); 
        U_losd = ux.*losd(:,1) + uy.*losd(:,2) + uz.*losd(:,3);
        figure
        subplot(1,2,1)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losa,'filled')
        title('Simulated Ascending in mm')
        subplot(1,2,2)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losd,'filled')
        title('Simulated Descending in mm')

 elseif source_flg == 'P'
    [U,dV] = pennySource(model(best,:),locs_ins',0.25);
        ux = U(1,:)';  uy = U(2,:)';  uz = U(3,:)';
             
        U_losa = ux.*losa(:,1) + uy.*losa(:,2) + uz.*losa(:,3); 
        U_losd = ux.*losd(:,1) + uy.*losd(:,2) + uz.*losd(:,3);
        figure
        subplot(1,2,1)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losa,'filled')
        title('Simulated Ascending in mm')
        subplot(1,2,2)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losd,'filled')
        title('Simulated Descending in mm')   

elseif source_flg == 'Y'
        [U] = yangSource(model(best,:),locs_ins',0.25);
        ux = U(1,:)';  uy = U(2,:)';  uz = U(3,:)';
             
        U_losa = ux.*losa(:,1) + uy.*losa(:,2) + uz.*losa(:,3); 
        U_losd = ux.*losd(:,1) + uy.*losd(:,2) + uz.*losd(:,3);
        figure
        subplot(1,2,1)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losa,'filled')
        title('Simulated Ascending in mm')
        subplot(1,2,2)
        scatter(xy_ins(:,1)/1000,xy_ins(:,2)/1000,50,U_losd,'filled')
        title('Simulated Descending in mm')   
    end
end


