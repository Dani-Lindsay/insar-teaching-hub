function [L1, L2, rms, normalised]=calc_misfit(obs, model)

% function [L1, L2, rms, normalised]=calc_misfit(obs, model)
% 
% Calculates the L1 and L2 norm misfits, and the mean misfit per datapoint,
% between a set of observed and modelled data. Both input datasets should be 
% column vectors.
%

% Do the variable thing

L1=0 ;
L2=0 ;
dsq=0 ;

% Count the number of datapoints

n=length(obs) ;

% Sift through the data point by point, calculate the
% misfit at each, and sum...

for i=1:n
    
    L1=L1+abs(obs(i)-model(i)) ;
    L2=L2+((obs(i)-model(i))^2) ;
    dsq=dsq+(obs(i))^2 ;
    
end

rms = sqrt(L2/n);
normalised=L2/dsq ;

