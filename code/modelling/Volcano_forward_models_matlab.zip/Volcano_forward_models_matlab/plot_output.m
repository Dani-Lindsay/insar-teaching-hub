
best = find(rms<min(rms)+rms_per*min(rms));

f = source_flg == 'F';
d = source_flg == 'D';
if d(1) == 1 || f(1) == 1
for p = 1:size(best,1)
%if op(best(p))/len(best(p)) > 1e-3
x_surf1 = model(best(p),1) - 0.5*model(best(p),7)*sind(model(best(p),3));
x_surf2 = model(best(p),1) + 0.5*model(best(p),7)*sind(model(best(p),3));
y_surf1 = model(best(p),2) - 0.5*model(best(p),7)*cosd(model(best(p),3));
y_surf2 = model(best(p),2) + 0.5*model(best(p),7)*cosd(model(best(p),3));

x_top1 = x_surf1 + model(best(p),8)*cosd(model(best(p),3))/tand(model(best(p),4));
x_top2 = x_surf2 + model(best(p),8)*cosd(model(best(p),3))/tand(model(best(p),4));
y_top1 = y_surf1 - model(best(p),8)*sind(model(best(p),3))/tand(model(best(p),4));
y_top2 = y_surf2 - model(best(p),8)*sind(model(best(p),3))/tand(model(best(p),4));

x_bot1 = x_surf1 + model(best(p),9)*cosd(model(best(p),3))/tand(model(best(p),4));
x_bot2 = x_surf2 + model(best(p),9)*cosd(model(best(p),3))/tand(model(best(p),4));
y_bot1 = y_surf1 - model(best(p),9)*sind(model(best(p),3))/tand(model(best(p),4));
y_bot2 = y_surf2 - model(best(p),9)*sind(model(best(p),3))/tand(model(best(p),4));


X(1:4,p) = [x_top1 x_top2 x_bot2 x_bot1]';
Y(1:4,p) = [y_top1 y_top2 y_bot2 y_bot1]';
Z(1:4,p) = [-model(best(p),8)  -model(best(p),8)  -model(best(p),9)  -model(best(p),9)]'/1000;

%subplot(4,1,1:3)
hold on
if p == 1
    fill3(X(:,p)/1000,Y(:,p)/1000,Z(:,p),model(best(p),6))
else
    fill3(X(:,p)/1000,Y(:,p)/1000,Z(:,p),model(best(p),6),'FaceAlpha',0.5)
end

end

elseif source_flg == 'SF'

    for p = 1:size(best,1)
    x_surf1 = model(best(p),1) - 0.5*model(best(p),7)*sind(model(best(p),3));
x_surf2 = model(best(p),1) + 0.5*model(best(p),7)*sind(model(best(p),3));
y_surf1 = model(best(p),2) - 0.5*model(best(p),7)*cosd(model(best(p),3));
y_surf2 = model(best(p),2) + 0.5*model(best(p),7)*cosd(model(best(p),3));

x_top1 = x_surf1 + model(best(p),8)*cosd(model(best(p),3))/tand(model(best(p),4));
x_top2 = x_surf2 + model(best(p),8)*cosd(model(best(p),3))/tand(model(best(p),4));
y_top1 = y_surf1 - model(best(p),8)*sind(model(best(p),3))/tand(model(best(p),4));
y_top2 = y_surf2 - model(best(p),8)*sind(model(best(p),3))/tand(model(best(p),4));

x_bot1 = x_surf1 + model(best(p),9)*cosd(model(best(p),3))/tand(model(best(p),4));
x_bot2 = x_surf2 + model(best(p),9)*cosd(model(best(p),3))/tand(model(best(p),4));
y_bot1 = y_surf1 - model(best(p),9)*sind(model(best(p),3))/tand(model(best(p),4));
y_bot2 = y_surf2 - model(best(p),9)*sind(model(best(p),3))/tand(model(best(p),4));


X(1:4,p) = [x_top1 x_top2 x_bot2 x_bot1]';
Y(1:4,p) = [y_top1 y_top2 y_bot2 y_bot1]';
Z(1:4,p) = [-model(best(p),8)  -model(best(p),8)  -model(best(p),9)  -model(best(p),9)]'/1000;

%subplot(4,1,1:3)
hold on
if p == 1
    fill3(X(:,p)/1000,Y(:,p)/1000,Z(:,p),model(best(p),6))
else
    fill3(X(:,p)/1000,Y(:,p)/1000,Z(:,p),model(best(p),6),'FaceAlpha',0.5)
end

 W = model_s(best(p),2)/2; L = model_s(best(p),1)/2;
        str = model_s(best(p),5);
        x_off = sind(str-90)*L;
        y_off = cosd(str-90)*L;

        Cx = model(best(p),6)+x_off;
        Cy = model(best(p),7)+y_off;

        xy = [W L; W -L;-W L;-W -L];

        rot = [cosd(str) sind(str);-sind(str) cosd(str)];
        xy1 = xy*rot;
        xy1(:,1) = xy1(:,1)+Cx; xy1(:,2) = xy1(:,2)+Cy; 

        sill_xy = [xy1(1,1) xy1(1,2); xy1(3,1) xy1(3,2);xy1(4,1) xy1(4,2);xy1(2,1) xy1(2,2);xy1(1,1) xy1(1,2)];
        fill3(sill_xy(:,1)/1000,sill_xy(:,2)/1000,-repmat(model_s(best(p),3),5,1)/1000,model_s(best(p),10))

    end

elseif source_flg == 'P'
    
    for i = 1:size(best,1)
        [X,Y,Z] = ellipsoid(model(best(i),1)/1000,model(best(i),2)/1000,-model(best(i),3)/1000,model(best(i),4)/1000,model(best(i),4)/1000,0.1);
        surf(X,Y,Z,repmat(model(best(i),5)/1e9,size(X)),'FaceAlpha',0.5,'EdgeColor','None');
        hold on
    end

elseif  source_flg == 'S'
    for i = 1:size(best,1)
    
        W = model(best(i),2)/2; L = model(best(i),1)/2;
        str = model(best(i),5);
        x_off = sind(str-90)*L;
        y_off = cosd(str-90)*L;

        Cx = model(best(i),6)+x_off;
        Cy = model(best(i),7)+y_off;

        xy = [W L; W -L;-W L;-W -L];

        rot = [cosd(str) sind(str);-sind(str) cosd(str)];
        xy1 = xy*rot;
        xy1(:,1) = xy1(:,1)+Cx; xy1(:,2) = xy1(:,2)+Cy; 

        sill_xy = [xy1(1,1) xy1(1,2); xy1(3,1) xy1(3,2);xy1(4,1) xy1(4,2);xy1(2,1) xy1(2,2);xy1(1,1) xy1(1,2)];
        fill3(sill_xy(:,1)/1000,sill_xy(:,2)/1000,-repmat(model(best(i),3),5,1)/1000,model(best(i),10))
        hold on
    end
elseif source_flg == 'Y'
% 1. Define the Spheroid Parameters

for i = 1:size(best,1)
strike_deg = model(best(i),6);  % Strike in degrees (clockwise from North/Y-axis)
dip_deg = model(best(i),7);     % Dip in degrees (angle from horizontal)
center = [model(best(i),1), model(best(i),2), -model(best(i),3)]; % Center of the ellipsoid (x, y, z)
rx = model(best(i),4); ry = model(best(i),4).*model(best(i),5); rz = model(best(i),4).*model(best(i),5); % Semi-axes lengths (x, y, z)
% -----------------------

% 1. Create unit-sized ellipsoid at the origin
[x, y, z] = ellipsoid(0,0,0,rx,ry,rz,30);

% 2. Define Rotation Matrices
% Convert degrees to radians
st = deg2rad(strike_deg);
dp = deg2rad(dip_deg);

% Rotation matrix for Dip (rotate around X-axis)
Rx = [1 0 0; 0 cos(dp) -sin(dp); 0 sin(dp) cos(dp)];

% Rotation matrix for Strike (rotate around Z-axis, clockwise)
Rz = [cos(st) -sin(st) 0; sin(st) cos(st) 0; 0 0 1];

% Combined Rotation Matrix: Apply dip first, then strike
R = Rz * Rx;

% 3. Apply Rotation
[n, m] = size(x);
points = [x(:), y(:), z(:)]'; % Convert to 3xN matrix
rotated_points = R * points;  % Apply rotation

% Reshape back to meshgrid
x_rot = reshape(rotated_points(1,:), n, m);
y_rot = reshape(rotated_points(2,:), n, m);
z_rot = reshape(rotated_points(3,:), n, m);

% 4. Translate (Move to center)
x_final = x_rot + center(1);
y_final = y_rot + center(2);
z_final = z_rot + center(3);
surfc(x_final/1000, y_final/1000, z_final/1000,model(best,8),'FaceColor', 'blue', 'EdgeColor', 'none');
hold on;
axis equal;
grid on;
xlabel('East (X)'); ylabel('North (Y)'); zlabel('Depth (Z)');


end

else


    scatter3(model(best,1)/1000,model(best,2)/1000,-model(best,4),200,model(best,3),'filled')
  
end

hold on

xy_gps = llh2local([gps(:,1) gps(:,2)]',[xc yc]); % convert from geodetic to metres.
xy_gps = xy_gps';
%island = load('lakes.txt');  

%xy_wh = llh2local([island(:,1) island(:,2)]',[xc yc]); % convert from geodetic to metres.
%xy_wh = xy_wh';
%plot(xy_wh(:,1),xy_wh(:,2),'k.')

plot(xy_gps(:,1),xy_gps(:,2),'k^')
axis equal
%axis([-10 10 -10 10])
%subplot(1,2,2)
if h_flg == 1

    for i = 1:size(best,1)
        quiver(xy_gps(:,1),xy_gps(:,2),disp(:,1,best(i)),disp(:,2,best(i)),0.5,'Color','k','LineWidth',1,'MaxHeadSize',0.03,'Marker','s')
        hold on
    end
        quiver(xy_gps(:,1),xy_gps(:,2),gps(:,3),gps(:,5),0.5,'Color','r','LineWidth',0.5,'MaxHeadSize',0.03,'Marker','s')

else

    for i = 1:size(best,1)
        quiver(xy_gps(:,1),xy_gps(:,2),disp(:,1,best(i)),disp(:,2,best(i)),0.5,'Color','k','LineWidth',1,'MaxHeadSize',0.03,'Marker','s')
        hold on
    end
        quiver(xy_gps(:,1),xy_gps(:,2),gps(:,3),gps(:,5),0.5,'Color','r','LineWidth',1,'MaxHeadSize',0.03,'Marker','s')

    for i = 1:size(best,1)
        quiver(xy_gps(:,1),xy_gps(:,2),zeros(size(xy_gps,1),1),disp(:,3,best(i)),1,'Color','m','LineWidth',3,'MaxHeadSize',0.03,'Marker','s')
        hold on
    end
    quiver(xy_gps(:,1),xy_gps(:,2),zeros(size(xy_gps,1),1),gps(:,7),1,'Color','b','LineWidth',1,'MaxHeadSize',0.03,'Marker','s')
end