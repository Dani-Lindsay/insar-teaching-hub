function[tot_asc] = test_mogi_inc(los,ifghdr,xc,yc,vol_change,depth)
%%%%%%%%%incidence anle x diplacement%%%%%%%%
addpath ~/codes/pirate/v3.1/


%% Load incidence data files and cut interferograms


%% Set up grid

x = ifghdr.xfirst:ifghdr.xstep:ifghdr.xfirst+(ifghdr.xstep*ifghdr.width)-ifghdr.xstep;
y = ifghdr.yfirst:ifghdr.ystep:ifghdr.yfirst+(ifghdr.ystep*ifghdr.length)-ifghdr.ystep;

xy = llh2local([x; y],[xc yc]);

x = xy(1,:); y = xy(2,:);

[xx,yy]=meshgrid(x,y);
xx = reshape(xx,[],1);
yy = reshape(yy,[],1);

xc = 0; yc = 0;

%% incidence angles and los vectors for ascending track
phi = (los(:,:,2)+90); los = los(:,:,1);
east = -sind(los).*cosd(phi); north = -sind(los).*sind(phi); up = -cosd(los);
east(los==0) = NaN;  north(los==0) = NaN;  up(los==0) = NaN;      
e_asc = reshape(east,[ ],1);
n_asc = reshape(north,[ ],1);
u_asc = reshape(up,[ ],1);
los_asc = [e_asc, n_asc, u_asc];

%% run rngchn.m for ascending

[tot1] = rngchn_mogi(yc,xc,depth,vol_change,yy,xx,los_asc);

tot_asc = reshape(tot1,size(los,1),size(los,2));

